import java.util.ArrayList;

public class Biblioteca {
    // lista de colecciones
    private ArrayList<Libro> listaLibros;
    private ArrayList<Usuario> listaUsuarios;
    private ArrayList<Prestamo> listaPrestamos;

    // Constructor, inicializa las listas vacias
    public Biblioteca() {
        this.listaLibros = new ArrayList<>();
        this.listaUsuarios = new ArrayList<>();
        this.listaPrestamos = new ArrayList<>();
    } // Fin biblioteca

    public void registrarLibro(String codigo, String titulo, String autor) {
        Libro nuevoLibro = new Libro(codigo, titulo, autor);
        listaLibros.add(nuevoLibro);
        System.out.println("Libro registrado con exito!");
    } // registrar libro void

    // Metodo para registrar un nuevo usuario en la lista
    public void registrarUsuario(String nombreUsuario, String tipoIdentificacion, String numeroIdentificacion, String correo) {
        Usuario nuevoUsuario = new Usuario(nombreUsuario, tipoIdentificacion, numeroIdentificacion, correo);
        listaUsuarios.add(nuevoUsuario);
        System.out.println("¡Usuario registrado con éxito!");
    } // registrar usuario void

    // metodo para consultar, mostrar todos los libros de la biblioteca
    public void mostrarLibros() {
        if (listaLibros.isEmpty()) { 
            System.out.println("No hay libros registrados en la biblioteca.");
        } else { 
            System.out.println("\n--- LISTA DE LIBROS ---");
            for (Libro libro : listaLibros) { 
                libro.mostrarInfo();
            } 
        } 
    } // <-- AQUÍ FALTABA ESTA LLAVE PARA CERRAR mostrarLibros()

    // Metodo para buscar un libro por su código
    public Libro buscarLibro(String codigo) {
        for (Libro libro : listaLibros) {
            if (libro.getCodigo().equalsIgnoreCase(codigo)) {
                return libro;
            }
        }
        return null; // Si no lo encuentra
    }

    // Metodo para buscar un usuario por su número de identificación
    public Usuario buscarUsuario(String numeroId) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getNumeroIdentificacion().equals(numeroId)) {
                return usuario;
            }
        }
        return null; // Si no lo encuentra
    }

    // Validando disponibilidad
    public void realizarPrestamo(String codigoLibro, String numeroIdUsuario, String fecha) {
        Libro libroEncontrado = buscarLibro(codigoLibro);
        Usuario usuarioEncontrado = buscarUsuario(numeroIdUsuario);

        if (libroEncontrado == null) {
            System.out.println("Error: El libro con código " + codigoLibro + " no existe.");
            return;
        }

        if (usuarioEncontrado == null) {
            System.out.println("Error: El usuario con ID " + numeroIdUsuario + " no está registrado.");
            return;
        }

        // Evitar prestar libros que ya estén prestados
        if (!libroEncontrado.isDisponible()) {
            System.out.println("Lo sentimos, el libro '" + libroEncontrado.getTitulo() + "' ya se encuentra prestado.");
            return;
        }

        // Si pasa las validaciones, creamos el préstamo
        Prestamo nuevoPrestamo = new Prestamo(libroEncontrado, usuarioEncontrado, fecha);
        listaPrestamos.add(nuevoPrestamo);
        System.out.println("¡Préstamo realizado con éxito al usuario " + usuarioEncontrado.getNombreUsuario() + "!");
    }
} // fin clase biblioteca