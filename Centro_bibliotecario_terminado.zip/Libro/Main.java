import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Biblioteca biblio = new Biblioteca();
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        do {
            System.out.println("\n--- SISTEMA DE GESTIÓN DE BIBLIOTECA ---");
            System.out.println("1. Registrar libro");
            System.out.println("2. Registrar usuario");
            System.out.println("3. Consultar libros");
            System.out.println("4. Realizar préstamo");
            System.out.println("5. Salir");
            System.out.print("Elija una opción: ");
            
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar el buffer

                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese código del libro: ");
                        String codigo = scanner.nextLine();
                        System.out.print("Ingrese título: ");
                        String titulo = scanner.nextLine();
                        System.out.print("Ingrese autor: ");
                        String autor = scanner.nextLine();
                        biblio.registrarLibro(codigo, titulo, autor);
                        break;

                    case 2:
                        System.out.print("Ingrese tipo de identificación (CC, TI, etc.): ");
                        String tipoId = scanner.nextLine();
                        System.out.print("Ingrese número de identificación: ");
                        String numId = scanner.nextLine();
                        System.out.print("Ingrese nombre del usuario: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Ingrese correo electrónico: ");
                        String correo = scanner.nextLine();
                        biblio.registrarUsuario(nombre, tipoId, numId, correo);
                        break;

                    case 3:
                        biblio.mostrarLibros();
                        break;

                    case 4:
                        System.out.print("Ingrese el código del libro a prestar: ");
                        String codLibro = scanner.nextLine();
                        System.out.print("Ingrese el número de identificación del usuario: ");
                        String idUsuario = scanner.nextLine();
                        System.out.print("Ingrese la fecha de préstamo (ej: 10/11/2026): ");
                        String fecha = scanner.nextLine();
                        biblio.realizarPrestamo(codLibro, idUsuario, fecha);
                        break;

                    case 5:
                        System.out.println("Saliendo del sistema... ¡Hasta luego!");
                        break;

                    default:
                        System.out.println("Opción inválida. Intente de nuevo.");
                }
            } else {
                System.out.println("Por favor, ingrese un número válido.");
                scanner.next(); // Limpiar entrada incorrecta
            }

        } while (opcion != 5);

        scanner.close();
    }
}