public class Prestamo {
    // Atributos privados
    private Libro libro;
    private Usuario usuario;
    private String fechaPrestamo;
    private String estado;

    // Constructor: al crear el préstamo, nace Activo y el libro pasa a no disponible
    public Prestamo(Libro libro, Usuario usuario, String fechaPrestamo) {
        this.libro = libro;
        this.usuario = usuario;
        this.fechaPrestamo = fechaPrestamo;
        this.estado = "Activo";
        
        // Cambiamos el estado del libro a prestado (false)
        this.libro.setDisponible(false);
    }

    // Getters y Setters
    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(String fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    // Metodo para finalizar el prestamo cuando devuelven el libro
    public void finalizarPrestamo() {
        this.estado = "Finalizado";
        this.libro.setDisponible(true); // El libro vuelve a estar disponible
        System.out.println("El préstamo ha finalizado. El libro '" + libro.getTitulo() + "' ahora está disponible.");
    }
} // Fin clase prestamo