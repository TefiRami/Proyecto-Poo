public class Libro {
    // Aplicando Encapsulamiento
    private String codigo;
    private String titulo;
    private String autor;
    private boolean disponible; // true si esta disponible, false si esta prestado

    // CONSTRUCTOR:Inicializa el objeto
    public Libro(String codigo, String titulo, String autor) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = true; // Por defecto, al registrar un libro nuevo esta disponible
    }

    //  Metodos para acceder y modificar los atributos privados de forma segura
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    // Metodo auxiliar, muestra la información del libro de forma ordenada
    public void mostrarInfo() {
        String estadoTexto = disponible ? "Disponible" : "Prestado";
        System.out.println("Código: " + codigo + " | Título: " + titulo + " | Autor: " + autor + " | Estado: " + estadoTexto);
    }
}