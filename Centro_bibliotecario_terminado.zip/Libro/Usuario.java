public class Usuario {//inicio clase
    private String nombreUsuario;
    private String tipoIdentificacion;
    private String numeroIdentificacion;
    private String correo;

public Usuario(String nombreUsuario, String tipoIdentificacion, String numeroIdentificacion, String correo) {// inicio constructor 
    this.nombreUsuario = nombreUsuario;
    this.tipoIdentificacion = tipoIdentificacion;
    this.numeroIdentificacion = numeroIdentificacion;
    this.correo = correo;
}// fin constructor
// get para consultar nombre
public String getNombreUsuario(){// I get nombre
    return nombreUsuario;
}// F GET NOMBRE

// set para modificar nombre
public void setNombreUsuario(String tipoIdentificacion){// I set nombre
    this.nombreUsuario = nombreUsuario;
} // fin set nombre
// Getter para consultar el 
public String getTipoIdentificacion() {
    return tipoIdentificacion;
}

// Setter para modificar el nombre
public void setTipoIdentificacion(String tipoIdentificacion) {
    this.tipoIdentificacion = tipoIdentificacion;
}// set

// Getter y Setter para numeroIdentificacion
    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    // Getter y Setter para correo
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    // Método para mostrar la información del usuario de forma ordenada
    public void mostrarInfoUsuario() {
        System.out.println("Tipo ID: " + tipoIdentificacion + " | Número ID: " + numeroIdentificacion + " | Nombre: " + nombreUsuario + " | Correo: " + correo);
    } 

}// fin clase